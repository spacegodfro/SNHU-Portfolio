﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CreateClassesObjs
{
    public class Course
    {
        // Holds the course name
        private string name;

        // Sets the name field
        public void setName(string name)
        { this.name = name; }

        // gets the name field
        public string getName()
        { return this.name; }

        // Overide of ToString() to return the name
        public override string ToString()
        {
            return name;
        }
    }
}
