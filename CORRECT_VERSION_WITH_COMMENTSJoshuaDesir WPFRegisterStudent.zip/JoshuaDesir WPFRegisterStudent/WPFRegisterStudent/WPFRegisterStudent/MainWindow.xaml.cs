﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WPFRegisterStudent
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        // Variable to hold the currenlty selected course.
        Course choice; 

        // Makeshift way to handle the amount of credit hours each course is equal to.
        Dictionary<Course, int> CreditHours = new Dictionary<Course, int>();
        
        // Makeshift List used to track the courses that the user has registered for.
        private List<Course> courses = new List<Course>();
        
        // Variable that tracks the total credit hours a user is registered for. 
        private int totalCreditHours = 0;
        
        
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {

            Course course1 = new Course("IT 145");
            Course course2 = new Course("IT 200");
            Course course3 = new Course("IT 201");
            Course course4 = new Course("IT 270");
            Course course5 = new Course("IT 315");
            Course course6 = new Course("IT 328");
            Course course7 = new Course("IT 330");

            
            
            // Sets the credit hours for each course.
            CreditHours[course1] = 3;
            CreditHours[course2] = 3;
            CreditHours[course3] = 3;
            CreditHours[course4] = 3;
            CreditHours[course5] = 3;
            CreditHours[course6] = 3;
            CreditHours[course7] = 3;



            this.comboBox.Items.Add(course1);
            this.comboBox.Items.Add(course2);
            this.comboBox.Items.Add(course3);
            this.comboBox.Items.Add(course4);
            this.comboBox.Items.Add(course5);
            this.comboBox.Items.Add(course6);
            this.comboBox.Items.Add(course7);


            this.textBox.Text = "";
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            // Gets the chosen course and sets it to choice.
            choice = (Course)(this.comboBox.SelectedItem);


            // Checks if course selected is null. Happens when user doesnt make a selection. 
            if (choice == null)
            {
                label3.Content = "Please choose a course.";
            }

            // Checks if user has already registered for the course.
            else if (courses.Contains(choice))
            {
                label3.Content = "You are already registered for this course";
            }

            // Validates the courses and their credit hours.
            else if (CreditHours.TryGetValue(choice, out int credithours))
            {

                // Checks to make sure adding the course will not exceed 9 total credit hours. 
                if (totalCreditHours + credithours > 9)
                {
                    label3.Content = "Exceeding 9 Credit Hours.";
                }

                // Registers user for the course and updates apprpropriate areas of the WPF. 
                else
                {
                    totalCreditHours += credithours;
                    textBox.Text = totalCreditHours.ToString();
                    listBox.Items.Add(choice.getName());
                    courses.Add(choice);

                    label3.Content = $"You have successfully registered for {choice.getName()}.";
                }
                // TO DO - Create code to validate user selection (the choice object)
                // and to display an error or a registation confirmation message accordinlgy
                // Also update the total credit hours textbox if registration is confirmed for a selected course

            }

        }
    }
}
